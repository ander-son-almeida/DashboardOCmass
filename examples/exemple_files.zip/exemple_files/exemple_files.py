# -*- coding: utf-8 -*-
"""
Created on Tue Nov 14 22:38:21 2023

@author: Anderson Almeida
"""

import pandas as pd
import numpy as np

member_ships_np = np.load('pleiades.npy')
print(member_ships_np)

member_ships_df = pd.read_csv('pleiades.csv')
print(member_ships_df)